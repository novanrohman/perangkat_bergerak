import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:latihan1/pages/CounterPage.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text("Hey you, Hwaiting "),
        ),
        body: CounterPage(),
      ),
    );
  }
}

class CounterPage extends StatefulWidget {
  CounterPage({
    Key? key,
  }) : super(key: key);
  int counter_value = 65;

  @override
  State<CounterPage> createState() => _CounterPageState();
}
