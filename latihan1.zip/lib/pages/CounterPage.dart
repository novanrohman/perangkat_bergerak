import 'package:flutter/material.dart';

class _CounterPageState extends State<CounterPage> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            // "${widget.counter_value}",
            String.fromCharCode(widget.counter_value),
            style: TextStyle(fontSize: 36, fontStyle: FontStyle.normal),
          ),
          SizedBox(
            height: 28,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    widget.counter_value--;
                  });
                },
                child: Text(
                  "KURANG",
                  style: TextStyle(fontSize: 24),
                ),
              ),
              SizedBox(width: 40),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    widget.counter_value++;
                  });
                },
                style: ButtonStyle(),
                child: Text(
                  "TAMBAH",
                  style: TextStyle(fontSize: 24),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
